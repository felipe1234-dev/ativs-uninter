package system.enums;

public enum Level {
	EASY,
	NORMAL,
	HARD, 
	CUSTOM
}
