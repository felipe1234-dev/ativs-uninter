package system.enums;

public enum Player {
	HUMAN,
	COMPUTER
}