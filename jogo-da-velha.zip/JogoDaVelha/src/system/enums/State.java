package system.enums;

public enum State {
	PLAYING,
	TIE,
	WIN
}
