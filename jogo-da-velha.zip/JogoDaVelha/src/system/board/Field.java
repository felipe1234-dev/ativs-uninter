package system.board;

public class Field {
	public char text;
	
	public Field() {
		this.text = ' ';
	}
}
